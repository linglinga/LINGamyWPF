﻿using BookApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity; // add this for EF to work
using BookDB;
using System.ComponentModel;

namespace BookApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();                  //F8
            LoadBooks();            // call on method when main window is up    //F9
        }

        //add Mouse DoubleClick Event
        private void uxBookList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            uxFileChange_Click(sender, null); // call on Change Method to do the update
        }

        // do this when delete is selected
        private void uxFileDelete_Click(object sender, RoutedEventArgs e)
        {
            App.BookRepository.Remove(selectedBook.Id);
            selectedBook = null;
            LoadBooks();
        }

        // check the status of deletion, enable or disable the menu
        private void uxFileDelete_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileDelete.IsEnabled = (selectedBook != null);

            // Exercise: add the context menu deletion IsEnabled here
            uxContextFileDelete.IsEnabled = uxFileDelete.IsEnabled;
        }

        // for deletion: check selection being made
        private BookModel selectedBook;
        private object foundSame;
        private int bookId;

        //click on BookList will call this.
        private void uxBookList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {                                                               //D1         //S1
            selectedBook = (BookModel)uxBookList.SelectedValue;         //D2         //S2
        }                                                               //D3         //S3

        private void GridViewColumnHeader_Click(object sender, RoutedEventArgs e)
        {                                                                       //S1
            GridViewColumnHeader column = (sender as GridViewColumnHeader);     //S2

            // Grab the Tag from the column header
            string sortBy = column.Tag.ToString();                              //s3

            // Clear out any previous column sorting
            uxBookList.Items.SortDescriptions.Clear();                          //S4

            // Sort the uxContactList by the column header tag (sortBy)
            // If you want to do Descending, look at the homework :) and SortAdorner
            var sortDescription = new System.ComponentModel.SortDescription(sortBy,
                System.ComponentModel.ListSortDirection.Ascending);             //S5

            uxBookList.Items.SortDescriptions.Add(sortDescription);             //S6
        }                                                                       //S7

        // for menu and context menu update 
        private void uxFileChange_Click(object sender, RoutedEventArgs e)       //M
        {
            // add code for update here
            var window = new BookWindow();
            window.Book = selectedBook.Clone(); // Exercise under update

            if (window.ShowDialog() == true)
            {
                App.BookRepository.Update(window.Book.ToRepositoryModel());
                LoadBooks();
            }
        }

        // enable or disable the Modify menu for update
        private void uxFileChange_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileChange.IsEnabled = (selectedBook != null);
            uxContextFileChange.IsEnabled = uxFileChange.IsEnabled;
        }

        //Load Books Method
        private void LoadBooks()
        {
            var books = App.BookRepository.GetAll();

            uxBookList.ItemsSource = books
                .Select(t => BookModel.ToModel(t))
                .ToList();

            // OR
            //var uiContactModelList = new List<ContactModel>();
            //foreach (var repositoryContactModel in contacts)
            //{
            //    This is the .Select(t => ... )
            //    var uiContactModel = ContactModel.ToModel(repositoryContactModel);
            //
            //    uiContactModelList.Add(uiContactModel);
            //}

            //uxContactList.ItemsSource = uiContactModelList;
        }

        private void uxFileNew_Click(object sender, RoutedEventArgs e)
        {
            var window = new BookWindow();

            //F3

            if (window.ShowDialog() == true)                                //F4
            {
                var uiBookModel = window.Book;                              //F5

                //var repositoryInventoryModel = uiBookModel.ToRepositoryModel();

                //App.BookRepository.Add(repositoryBookModel);

                //// OR
                App.BookRepository.Add(window.Book.ToRepositoryModel());    //F6

                LoadBooks(); //when adding call on load contacts to show up //F7

            }
        }

        private void uxAdd_Click(object sender, RoutedEventArgs e)
        {                                                                   //F1 Add button
            uxFileNew_Click(sender, null);                                  //F2

        }

        //button click & load controlls.
        private void uxRemove_Click(object sender, RoutedEventArgs e)
        {                                                                   //D1 Remove button.
            uxFileDelete_Click(sender, null);                               //D2
        }                                                                   //D3

        private void uxRemove_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileDelete_Loaded(sender, null);
        }

        private void uxModify_Click(object sender, RoutedEventArgs e)
        {                                                                   //E1 Modify button.
            uxFileChange_Click(sender, null);                               //E2
        }
        private void uxModify_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileChange_Loaded(sender, null);
        }

        private void uxExit_Click(object sender, RoutedEventArgs e)
        {

            MessageBox.Show("\"The journey of a thousand miles starts with a single step.” \n\t\t\t\t~ Chinese Proverb \n You're one step closer to passing all 7 exams!"); //6
            Close();
        }


        //http://www.wpf-tutorial.com/dialogs/the-messagebox/
        private void uxSearchBar_TextChanged(object sender, TextChangedEventArgs e)
        {
            //enteredId = 
            //selectedBook = new 
            //(selectedBook.Id);
            //App.BookRepository.Find;


            var foundSameId = App.BookRepository.Find(bookId);


            //uxBookList.ItemsSource = books
            //    .Select(t => BookModel.ToModel(t))
            //    .ToList();


            //var foundSameId = (from book in BookRepository where t => t.BookId == bookId select book).ToList;
            if (foundSameId == true)
            {
                //    while (foundSameId != null)

                //        //while (from book in BookDB where t => t.BookId == bookId select book)
                //        //(t => t.BookId == bookId);

                //    {
                MessageBoxResult result = MessageBox.Show("Found Book ID" + "\n" + "\"Yes\" to Delete the Data" +
                                "\n" + "\"No\" to Update the Data." + "\n" + "\"Cancel\" back to Main Window", "Search by ID", MessageBoxButton.YesNoCancel);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        //uxFileDelete_Click(sender, null);
                        App.BookRepository.Remove(bookId);
                        uxSearchBar.Clear();
                        break;
                    case MessageBoxResult.No:
                        uxFileChange_Click(sender, null);
                        uxSearchBar.Clear();
                        break;
                    case MessageBoxResult.Cancel:
                        uxSearchBar.Clear();
                        break;
                }
            }
            MessageBox.Show("Book ID: {t.BookId}" + " Does not exist.");
            uxSearchBar.Clear();
        }

    }

    //private void uxSearchBar_TextChanged(object sender, TextChangedEventArgs e)
    //{
    //if (from book in BookDB where t => t.BookId == bookId select book)
    //{
    //    MessageBox.Show("Found Book ID: {t.BookId}, \n would you like to Remove it?", "Found Same ID", MessageBoxButton.YesNo);
    //    MessageBoxResult result = default(MessageBoxResult);
    //    switch (result)
    //    {
    //        case MessageBoxResult.Yes:
    //            uxFileDelete_Click(sender, null);
    //            MessageBox.Show("Deletion was a success!");
    //            break;
    //        case MessageBoxResult.No:

    //            MessageBox.Show("Oh, so nice of you!");
    //            var window = new MainWindow();
    //            break;
    //    }
    //}
    //else
    //{
    //    MessageBox.Show("Book ID: {t.BookId}" + " Does not exist.");
    //    uxSearchBar.Clear();
    //}
}





/* 033017 1:54pm Error: 2
 * Error CS7038 remains. 
 * Warning	CS0162	Unreachable code detected	BookApp	C:\sources\Final9\BookApp_Final\BookApp\MainWindow.xaml.cs	195	Active
 * 
 * 033017 7:30am Error CS7038 remains.
 * 
 * 
 * 032917 11:30pm Error: 1 
 * Error	CS7038	Failed to emit module 'BookApp'.	BookApp	C:\sources\Final9\BookApp_Final\BookApp\CSC	1	Active
 * 
 * 7 032917 12:31pm Error: 0
 * All errors corrected by fixing BookRepository.cs & BookModel.cs: mostly is BookModel vs bookModel.
 * 
 * 032917 10:23am Errors: 6
 * Error	CS1061	'BookModel' does not contain a definition for 'Clone' and no extension method 'Clone' accepting a first argument of type 'BookModel' could be found (are you missing a using directive or an assembly reference?)	BookApp	C:\sources\Final8\BookApp\BookApp\MainWindow.xaml.cs	84	Active
 *      line 84, 88, 130,
 * Error	CS0117	'BookModel' does not contain a definition for 'ToModel'	BookApp	C:\sources\Final8\BookApp\BookApp\MainWindow.xaml.cs	106	Active
 *      line 106
 * Error	CS0103	The name 'repositoryBookModel' does not exist in the current context	BookApp	C:\sources\Final8\BookApp\BookApp\MainWindow.xaml.cs	132	Active
 *      line 132,153
 * */
