﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookDB;                       //add this or else BooksEntities does not exist.
using System.Data.Entity.Validation;
// private Inventory ToDbModel(InventoryModel inventoryModel)
// does not exist.

namespace BookRepository
{
    public class BookModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Author { get; set; }
        public string Edition { get; set; }
        public string ISBN { get; set; }
        public int Quantity { get; set; }
        public string Notes { get; set; }
        public System.DateTime CreatedDate { get; set; }
    }

    public class BookRepository
    {
        public BookModel Add(BookModel bookModel)
        {
            var bookDb = ToDbModel(bookModel);

            DatabaseManager.Instance.Books.Add(bookDb);
            DatabaseManager.Instance.SaveChanges();

            bookModel = new BookModel
            {
                Quantity = bookDb.BookQuantity,
                CreatedDate = bookDb.BookCreatedDate,
                Author = bookDb.BookAuthor,
                Id = bookDb.BookId,
                Name = bookDb.BookName,
                Notes = bookDb.BookNotes,
                ISBN = bookDb.BookISBN,
                Edition = bookDb.BookEdition,
            };
            return bookModel;
        }

        public List<BookModel> GetAll()
        {
            // Use .Select() to map the database contacts to BookModel
            var items = DatabaseManager.Instance.Books
                  .Select(t => new BookModel
                  {
                      Quantity = t.BookQuantity,
                      CreatedDate = t.BookCreatedDate,
                      Author = t.BookAuthor,
                      Id = t.BookId,
                      Name = t.BookName,
                      Notes = t.BookNotes,
                      ISBN = t.BookISBN,
                      Edition = t.BookEdition,
                  }).ToList();

            return items;
        }

        public bool Update(BookModel bookModel)
        {
            var original = DatabaseManager.Instance.Books.Find(bookModel.Id);

            if (original != null)
            {
                DatabaseManager.Instance.Entry(original).CurrentValues.SetValues(ToDbModel(bookModel));
                DatabaseManager.Instance.SaveChanges();
            }

            return false;
        }

        public bool Remove(int bookId)
        {
            var items = DatabaseManager.Instance.Books
                                .Where(t => t.BookId == bookId);

            if (items.Count() == 0)
            {
                return false;
            }

            DatabaseManager.Instance.Books.Remove(items.First());
            DatabaseManager.Instance.SaveChanges();

            return true;
        }

        private Book ToDbModel(BookModel bookModel)
        {
            var bookDb = new Book
            {
                BookQuantity = bookModel.Quantity,
                BookCreatedDate = bookModel.CreatedDate,
                BookAuthor = bookModel.Author,
                BookId = bookModel.Id,
                BookName = bookModel.Name,
                BookNotes = bookModel.Notes,
                BookISBN = bookModel.ISBN,
                BookEdition = bookModel.Edition,
            };

            return bookDb;
        }
        
        public bool Find(int bookId)
        {
            var items = DatabaseManager.Instance.Books.Where(t => t.BookId == bookId);

            if (items.Count() == 0)
            {
                return false;
            }
            DatabaseManager.Instance.Entry(items.FirstOrDefault());
            return true;
        }



        //public void Find(int v, object bookId)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
/*
 * 2
 * 032917 10:38am Error: 1
 * Error	CS0120 corrected: changed BookModel to bookModel.
 * Error	CS1061	'BookModel' does not contain a definition for 'ToRepositoryModel' and no extension method 'ToRepositoryModel' accepting a first argument of type 'BookModel' could be found (are you missing a using directive or an assembly reference?)	BookApp	C:\sources\Final8\BookApp\BookApp\MainWindow.xaml.cs	130	Active
 *      line 83.
 * 

 * 
 * 
 * 
 * 
 * 
 * 032917 '
 * Error	CS0103	The name 'BookModel' corrected: Public class BookModel was correct.
 * Error	CS0120	An object reference is required for the non-static field, method, or property 'BookModel.Quantity'	BookRepository	C:\sources\Final8\BookApp\BookRepository\BookRepository.cs	100	Active
 * Error	CS1061	'BookModel' does not contain a definition for 'ToRepositoryModel' and no extension method 'ToRepositoryModel' accepting a first argument of type 'BookModel' could be found (are you missing a using directive or an assembly reference?)	BookApp	C:\sources\Final8\BookApp\BookApp\MainWindow.xaml.cs	130	Active
 * 

 * 
 * 
 * 032917 9:24am Error: 16. 
 * Error	CS0246	The type or namespace name 'BookModel' could not be found (are you missing a using directive or an assembly reference?)	BookRepository	C:\sources\Final8\BookApp\BookRepository\BookRepository.cs	24	Active
 * Error	CS0103	The name 'BookModel', etc., does not exist in the current context	BookRepository	C:\sources\Final8\BookApp\BookRepository\BookRepository.cs	97	Active      Line 100-107.
 * 
 * */


