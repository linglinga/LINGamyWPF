﻿using BookApp.Models;               //add this or else BooksEntities does not exist.
using System;
using System.Windows;


namespace BookApp
{
    /// <summary>
    /// Interaction logic for BookWindow.xaml
    /// </summary>
    public partial class BookWindow : Window
    {
        public BookModel Book { get; set; }
        public BookWindow()
        {
            InitializeComponent();
            // Don't show this window in the task bar
            ShowInTaskbar = false;
        }

        // for update use code to update the radio buttons and the date
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (Book != null)
            {
                uxSubmit.Content = "Update";
            }
            else
            {
                Book = new Models.BookModel();
                Book.CreatedDate = DateTime.Now;
            }
            uxGrid.DataContext = Book;
        } // end of updating the radio buttons

        private void uxSubmit_Click(object sender, RoutedEventArgs e)
        {

            var window = new MainWindow();
            Application.Current.MainWindow = window;
            DialogResult = true;
            Close();

        }

        private void uxExit_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            MessageBox.Show("\"The journey of a thousand miles starts with a single step.” \n\t\t\t\t~ Chinese Proverb \n You're one step closer to passing all 7 exams!");
            Close();
        }
    }

}

/*
 * 5. 032917 9:47am Errors: 0
 * 
 * */
