﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace BookApp.Models
{
    public class BookModel
    {
        public int Id { get; set; }
        public string Name { get; set; }            //D4    //D9    //D14   //D19   //D24       //S7    //S12   //S17   //S22   //S27
        public string Author { get; set; }          //D6    //D11   //D16   //D21   //D26       //S9    //S14   //S19   //S24   //S29
        public string Edition { get; set; }         //D7    //D12   //D17   //D22   //D27       //S10   //S15   //S20   //S25   //S30
        public string ISBN { get; set; }            //D8    //D13   //D18   //D23   //D28       //s11   //S16   //S21   //S26   //S31
        public int Quantity { get; set; }           //D5    //D10   //D15   //D20   //D25       //S8    //S13   //S18   //S23   //S28
        public string Notes { get; set; }
        public System.DateTime CreatedDate { get; set; }

        //D28: Deleted, back to MainWindow.
        internal BookModel Clone()
        {
            return (BookModel)MemberwiseClone(); // unboxing to get BookModel
        }

        public BookRepository.BookModel ToRepositoryModel()
        {
            var repositoryModel = new BookRepository.BookModel
            {
                Quantity = Quantity,
                CreatedDate = CreatedDate,
                Author = Author,
                Id = Id,
                Name = Name,
                Notes = Notes,
                ISBN = ISBN,
                Edition = Edition,
            };

            return repositoryModel;
        }

        public static BookModel ToModel(BookRepository.BookModel respositoryModel)
        {
            var bookModel = new BookModel
            {
                Quantity = respositoryModel.Quantity,
                CreatedDate = respositoryModel.CreatedDate,
                Author = respositoryModel.Author,
                Id = respositoryModel.Id,
                Name = respositoryModel.Name,
                Notes = respositoryModel.Notes,
                ISBN = respositoryModel.ISBN,
                Edition = respositoryModel.Edition,
            };

            return bookModel;
        }
    }
}

/*
 *3
 * 032917 12:14pm Error: 0
 * Error CS0116 & CS0103 corrected: Public class BookModel closing brackets were on Line 21 instead of 61.
 * 
 * 
 * 
 * 032917 10:31am Error: 10
 * Error	CS0116	A namespace cannot directly contain members such as fields or methods	BookApp	C:\sources\Final8\BookApp\BookApp\Models\BookModel.cs	22	Active      
 *      line 22, 23. ToRepository & ToModel
 * Error	CS0103	The name 'Author','ID', etc., does not exist in the current context	BookApp	C:\sources\Final8\BookApp\BookApp\Models\BookModel.cs	28	Active   
 *      line 24-33. 

 * 
 * 
 * 
 * 032917 9:38am Error:  9. Totals to 29.
 * Error	CS0103	The name 'Author','ID', etc., does not exist in the current context	BookApp	C:\sources\Final8\BookApp\BookApp\Models\BookModel.cs	28	Active
 * 
 * */
