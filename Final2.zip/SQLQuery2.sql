USE [Inventories]
GO
/****** Object:  Table [dbo].[Inventory]    Script Date: 3/25/2017 06:43:38 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Inventory](
	[InventoryId] [int] IDENTITY(1,1) NOT NULL,
	[InventoryName] [nvarchar](50) NOT NULL,
	[InventoryQuantity] [int] NULL,
	[InventoryPricePerItem] [decimal](9,2) NULL,
	[InventoryCostPerItem] [decimal](9,2) NULL,
	[InventoryItemValue] [decimal](9,2),
	[InventoryNotes] [nvarchar](1000) NULL,
    [InventoryCreatedDate] [datetime] NOT NULL CONSTRAINT [DF_Inventory_InventoryCreatedDate]  DEFAULT (getdate()),
 CONSTRAINT [PK_Inventory] PRIMARY KEY CLUSTERED 
(
	[InventoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, 
IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO