﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls; /* use this */
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using InventoryApp.Models; /* use this or InventoryRepository won't work*/


namespace InventoryApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadInventories();
        }

        //add Mouse DoubleClick Event
        private void uxInventoryList_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            uxFileChange_Click(sender, null); // call on Change Method to do the update
        }

        private void uxFileDelete_Click(object sender, RoutedEventArgs e)
        {
            App.InventoryRepository.Remove(selectedInventory.Id);
            selectedInventory = null;
            LoadInventories();
        }

        // check the status of deletion, enable or disable the menu
        private void uxFileDelete_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileDelete.IsEnabled = (selectedInventory != null);

            // Exercise: add the context menu deletion IsEnabled here
            uxContextFileDelete.IsEnabled = uxFileDelete.IsEnabled;
        }

        // for deletion: check selection being made
        private InventoryModel selectedInventory;

        private void uxInventoryList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedInventory = (InventoryModel)uxInventoryList.SelectedValue;
        }

        private void GridViewColumnHeader_Click(object sender, RoutedEventArgs e)
        {
            GridViewColumnHeader column = (sender as GridViewColumnHeader);

            // Grab the Tag from the column header
            string sortBy = column.Tag.ToString();

            // Clear out any previous column sorting
            uxInventoryList.Items.SortDescriptions.Clear();

            // Sort the uxContactList by the column header tag (sortBy)
            // If you want to do Descending, look at the homework :) and SortAdorner
            var sortDescription = new System.ComponentModel.SortDescription(sortBy,
                System.ComponentModel.ListSortDirection.Ascending);

            uxInventoryList.Items.SortDescriptions.Add(sortDescription);
        }

        // for menu and context menu update 
        private void uxFileChange_Click(object sender, RoutedEventArgs e)
        {
            // add code for update here
            var window = new InventoryWindow();
            window.Inventory = selectedInventory.Clone(); // Exercise under update

            if (window.ShowDialog() == true)
            {
                App.InventoryRepository.Update(window.Inventory.ToRepositoryModel());
                LoadInventories();
            }
        }

        // enable or disable the Modify menu for update
        private void uxFileChange_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileChange.IsEnabled = (selectedInventory != null);
            uxContextFileChange.IsEnabled = uxFileChange.IsEnabled;
        }

        // Add the Load Inventories Method
        private void LoadInventories()
        {
            var inventories = App.InventoryRepository.GetAll();

            uxInventoryList.ItemsSource = inventories
                .Select(t => InventoryModel.ToModel(t))
                .ToList();

            // OR
            //var uiContactModelList = new List<ContactModel>();
            //foreach (var repositoryContactModel in contacts)
            //{
            //    This is the .Select(t => ... )
            //    var uiContactModel = ContactModel.ToModel(repositoryContactModel);
            //
            //    uiContactModelList.Add(uiContactModel);
            //}

            //uxContactList.ItemsSource = uiContactModelList;
        }

        private void uxFileNew_Click(object sender, RoutedEventArgs e)
        {
            var window = new InventoryWindow();

            if (window.ShowDialog() == true)
            {
                var uiInventoryModel = window.Inventory;

                var repositoryInventoryModel = uiInventoryModel.ToRepositoryModel();

                App.InventoryRepository.Add(repositoryInventoryModel);

                // OR
                //App.ContactRepository.Add(window.Contact.ToRepositoryModel());

                LoadInventories(); //when adding call on load contacts to show up
            }
        }





        private void uxAdd_Click(object sender, RoutedEventArgs e)
        {
            var window = new InventoryWindow();

            if (window.ShowDialog() == true)
            {
                var uiInventoryModel = window.Inventory;

                var repositoryInventoryModel = uiInventoryModel.ToRepositoryModel();

                App.InventoryRepository.Add(repositoryInventoryModel);

                // OR
                //App.ContactRepository.Add(window.Contact.ToRepositoryModel());
            }
        }


        private void uxRemove_Click(object sender, RoutedEventArgs e)
        {
            uxFileDelete_Click(sender, null);
        }

        private void uxRemove_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileDelete_Loaded(sender, null);
        }

        private void uxModify_Click(object sender, RoutedEventArgs e)
        {
            uxFileChange_Click(sender, null);
        }
        private void uxModify_Loaded(object sender, RoutedEventArgs e)
        {
            uxFileChange_Loaded(sender, null);
        }
        private void uxExit_Click(object sender, RoutedEventArgs e)
        {
            uxExit_Click(sender, null);
        }

        private void uxSearchBar_TxtChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}

