﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity; /* add this for EF to work*/

namespace InventoryApp
{
    /// <summary>
    /// Interaction logic for WelcomeWindow.xaml
    /// </summary>
    public partial class WelcomeWindow : Window
    {
        public WelcomeWindow()      //1.
        {                           //2.
            InitializeComponent();  //3. initialize the components of WelcomeWindow, background color depenbdencies, etc.
            
        }                           //4.

        private void uxEnter_Click(object sender, RoutedEventArgs e)
        {                           //5. for ENTER
            //int x = 1;
            //x = x / (x - 1); // Induce a DivideByZeroException

            var window = new MainWindow();
            Application.Current.MainWindow = window;
            DialogResult = true;

            Close();
            window.Show();
        }

        private void uxExit_Click(object sender, RoutedEventArgs e)
        {                               //5. for exit
            //DialogResult = false;
            MessageBox.Show("\"The journey of a thousand miles starts with a single step.” \n\t\t\t\t~ Chinese Proverb \n You're one step closer to passing all 7 exams!"); //6.
            Close();        //7.
        }                   //8.
    }
}

/* 032817 11:30am Error: 0 (entire App)
 * all error fixed itself.
 * 
 * SQL Server cannot safe table: this fixed it.
 * //https://support.microsoft.com/en-us/help/956176/error-message-when-you-try-to-save-a-table-in-sql-server-saving-changes-is-not-permitted
 * 
 * 032717 10:15pm Error: 3
 * http://stackoverflow.com/questions/1421862/metadata-file-dll-could-not-be-found
 * Error	CS0006	Metadata file 'C:\sources\Final\InventoryApp\InventoryRepository\bin\Debug\InventoryRepository.dll' could not be found	InventoryApp	C:\sources\Final\InventoryApp\InventoryApp\CSC	1	Active
 * 
 * 
 * 
 * */

