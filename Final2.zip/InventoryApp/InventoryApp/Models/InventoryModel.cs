﻿using System;   /*Add this*/
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryApp.Models;  /*Add this*/
using System.ComponentModel;



namespace InventoryApp.Models
{
    public class InventoryModel 

    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Quantity { get; set; }
        public decimal PricePerItem { get; set; }
        public decimal CostPerItem { get; set; }
        public decimal ItemValue { get; set; }
        public string Notes { get; set; }
        public System.DateTime CreatedDate { get; set; }

       

        internal InventoryModel Clone()
        {
            return (InventoryModel)MemberwiseClone(); // unboxing to get InventoryModel
        }

        public InventoryRepository.InventoryModel ToRepositoryModel()
        {
            var repositoryModel = new InventoryRepository.InventoryModel
            {
                CostPerItem = CostPerItem,
                CreatedDate = CreatedDate,
                Name = Name,
                Id = Id,
                ItemValue = ItemValue,
                Notes = Notes,
                PricePerItem = PricePerItem,
                Quantity = Quantity,
            };

            return repositoryModel;
        }

        public static InventoryModel ToModel(InventoryRepository.InventoryModel respositoryModel)
        {
            var inventoryModel = new InventoryModel
            {
                CostPerItem = respositoryModel.CostPerItem,
                CreatedDate = respositoryModel.CreatedDate,
                Name = respositoryModel.Name,
                Id = respositoryModel.Id,
                ItemValue = respositoryModel.ItemValue,
                Notes = respositoryModel.Notes,
                PricePerItem = respositoryModel.PricePerItem,
                Quantity = respositoryModel.Quantity
            };

            return inventoryModel;
        }



        
    }
}

/*3
 * 032717 8:42pm  Errors: none
 * Line 28 corrected, Errors: 3 are corrected.
 * 
 * 
 * 
 * 032717 3:29pm Errors: 3
 * Error	CS0234	The type or namespace name 'InventoryModel' does not exist in the namespace 'InventoryRepository' (are you missing an assembly reference?)	InventoryApp	C:\sources\Final\InventoryApp\InventoryApp\Models\InventoryModel.cs	22	Active
 * Line 22, 39, 24.
 */
