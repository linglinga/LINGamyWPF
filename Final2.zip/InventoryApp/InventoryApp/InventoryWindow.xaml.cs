﻿using InventoryApp.Models; /*Add this*/
using InventoryDB;
using System;               /*Add this*/
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;   /*Add this*/
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity; // add this for EF to work








namespace InventoryApp
{
    /// <summary>
    /// Interaction logic for InventoryWindow.xaml
    /// </summary>
    public partial class InventoryWindow : Window
    {
        //private InventoryModel InventoryModel = new InventoryModel(); //can be written as: private Models.InventoryModel InventoryModel = new Models.InventoryModel();
        //private readonly object DatabaseManager;

        public InventoryWindow()
        {
            InitializeComponent();
            // Don't show this window in the task bar
            ShowInTaskbar = false;
        }

        // for update use code to update the radio buttons and the date
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (Inventory != null)
            {
                uxSubmit.Content = "Update";
            }
            else
            {
                Inventory = new InventoryModel();
                Inventory.CreatedDate = DateTime.Now;
            }
            uxGrid.DataContext = Inventory;
        } // end of updating the radio buttons

        private void uxSubmit_Click(object sender, RoutedEventArgs e)
        {

            DialogResult = true;
            Close(); // close contact window once the update is complete

            int x = 1;
            x = x / (x - 1); // Induce a DivideByZeroException


            MessageBox.Show("Submitting Inventory: \n Name:" + uxName.Name);
            var window = new MainWindow();
            Application.Current.MainWindow = window;
            Close();
            window.Show();

        }

        private void uxExit_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            MessageBox.Show("\"The journey of a thousand miles starts with a single step.” \n\t\t\t\t~ Chinese Proverb \n You're one step closer to passing all 7 exams!");
            Close();
        }
public InventoryModel Inventory { get; set; }

        





    }
}

/*032717 9:25pm Error: 0
 * parsed all string to int/decimal
 * 
 * 
 * 
 * 
 * 032717 5:56pm
 * Error: 1 Line 41
 * Error	CS0029	Cannot implicitly convert type 'string' to 'decimal'	InventoryApp	C:\sources\Final\InventoryApp\InventoryApp\InventoryWindow.xaml.cs	41	Active
 */