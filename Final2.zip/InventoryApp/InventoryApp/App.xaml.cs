﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;   /*Add this*/

namespace InventoryApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static InventoryRepository.InventoryRepository inventoryRepository;

        static App()
        {
            inventoryRepository = new InventoryRepository.InventoryRepository();
        }

        public static InventoryRepository.InventoryRepository InventoryRepository
        {
            get
            {
                return inventoryRepository;
            }
        }
    }
}

/*
 * 4    032717 10:41pm Error: 0
 * change class to public and delete duplicated class: error fixed.
 * 
 * 
 * 
 * 
 * 032717 4:54pm. 
 * Error: InventoryRepository is inaccessible due to its protection level.
 * 3 of them but not showing up in Error List. Line 16, 20, 23.
 * 
 */
