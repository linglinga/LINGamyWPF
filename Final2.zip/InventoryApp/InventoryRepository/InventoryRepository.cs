﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryDB; //   //add this or else 
                   // private Inventory ToDbModel(InventoryModel inventoryModel)
                   // does not exist.


namespace InventoryRepository
{
   
        public class InventoryModel
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int Quantity { get; set; }
            public decimal PricePerItem { get; set; }
            public decimal CostPerItem { get; set; }
            public decimal ItemValue { get; set; }
            public string Notes { get; set; }
            public System.DateTime CreatedDate { get; set; }
        }

        public class InventoryRepository
        {
            public InventoryModel Add(InventoryModel inventoryModel)
            {
                var inventoryDb = ToDbModel(inventoryModel);

                DatabaseManager.Instance.Inventories.Add(inventoryDb);
                DatabaseManager.Instance.SaveChanges();

                inventoryModel = new InventoryModel
                {
                    ItemValue = inventoryDb.InventoryItemValue.GetValueOrDefault(),
                    CreatedDate = inventoryDb.InventoryCreatedDate,
                    Quantity = inventoryDb.InventoryQuantity.GetValueOrDefault(),
                    Id = inventoryDb.InventoryId,
                    Name = inventoryDb.InventoryName,
                    Notes = inventoryDb.InventoryNotes,
                    CostPerItem = inventoryDb.InventoryCostPerItem.GetValueOrDefault(),
                    PricePerItem = inventoryDb.InventoryPricePerItem.GetValueOrDefault(),
                };
                return inventoryModel;
            }

        

        public List<InventoryModel> GetAll()
            {
                // Use .Select() to map the database inventories to InventoryModel
                var items = DatabaseManager.Instance.Inventories
                  .Select(t => new InventoryModel
                  {
                      /*http://stackoverflow.com/questions/4871994/how-can-i-convert-decimal-to-decimal*/
                      ItemValue = t.InventoryItemValue.GetValueOrDefault(),
                      CreatedDate = t.InventoryCreatedDate,
                      Quantity = t.InventoryQuantity.GetValueOrDefault(),
                      Id = t.InventoryId,
                      Name = t.InventoryName,
                      Notes = t.InventoryNotes,
                      CostPerItem = t.InventoryCostPerItem.GetValueOrDefault(),
                      PricePerItem = t.InventoryPricePerItem.GetValueOrDefault(),
                  }).ToList();

                return items;
            }

            public bool Update(InventoryModel inventoryModel)
            {
                var original = DatabaseManager.Instance.Inventories.Find(inventoryModel.Id);

                if (original != null)
                {
                    DatabaseManager.Instance.Entry(original).CurrentValues.SetValues(ToDbModel(inventoryModel));
                    DatabaseManager.Instance.SaveChanges();
                }

                return false;
            }

            public bool Remove(int InventoryId)
            {
                var items = DatabaseManager.Instance.Inventories
                                    .Where(t => t.InventoryId == InventoryId);

                if (items.Count() == 0)
                {
                    return false;
                }

                DatabaseManager.Instance.Inventories.Remove(items.First());
                DatabaseManager.Instance.SaveChanges();

                return true;
            }

            private Inventory ToDbModel(InventoryModel inventoryModel)
            {
                var inventoryDb = new Inventory
                {
                    InventoryItemValue = inventoryModel.ItemValue,
                    InventoryCreatedDate = inventoryModel.CreatedDate,
                    InventoryQuantity = inventoryModel.Quantity,
                    InventoryId = inventoryModel.Id,
                    InventoryName = inventoryModel.Name,
                    InventoryNotes = inventoryModel.Notes,
                    InventoryCostPerItem = inventoryModel.CostPerItem,
                    InventoryPricePerItem = inventoryModel.PricePerItem,
                };

                return inventoryDb;
            }
        }
    }


/*2  072717 10:05pm Error: 0
 * .GetValueOrDefault() for error: Error CS0266.
 * Erro CS0524: fixed by fixing other error: double class.

 * 032717 3:06pm. Errors: 9
 * public class InventoryRepository: 
 * Error CS0542  'InventoryRepository': member names cannot be the same as their enclosing type InventoryRepository C:\sources\Final\InventoryApp\InventoryRepository\InventoryRepository.cs	27	Active
 * fixed: double class InventoryRepository.
 * 
 * ItemValue = inventoryDb.InventoryItemValue, inventoryDb.InventoryCostPerItem,inventoryDb.InventoryPricePerItem: 
 *      Error CS0266  Cannot implicitly convert type 'decimal?' to 'decimal'. An explicit conversion exists (are you missing a cast?) InventoryRepository C:\sources\Final\InventoryApp\InventoryRepository\InventoryRepository.cs	42	Active
 * inventoryDb.InventoryQuantity : 
 *      Error CS0266  Cannot implicitly convert type 'int?' to 'int'. An explicit conversion exists (are you missing a cast?) InventoryRepository C:\sources\Final\InventoryApp\InventoryRepository\InventoryRepository.cs	45	Active
 * public List<InventoryModel> GetAll():
 * t.InventoryItemValue, inventoryDb.InventoryCostPerItem, inventoryDb.InventoryPricePerItem: 
 *      Error CS0266  Cannot implicitly convert type 'decimal?' to 'decimal'. An explicit conversion exists (are you missing a cast?) InventoryRepository C:\sources\Final\InventoryApp\InventoryRepository\InventoryRepository.cs	42	Active
 * t.InventoryQuantity : 
 * Error CS0266  Cannot implicitly convert type 'int?' to 'int'. An explicit conversion exists (are you missing a cast?) InventoryRepository C:\sources\Final\InventoryApp\InventoryRepository\InventoryRepository.cs	45	Active

*/
