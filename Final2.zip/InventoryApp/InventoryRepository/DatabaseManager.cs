﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InventoryDB; // //add this or else InventoriesEntities does not exist.

namespace InventoryRepository   
{
    public class DatabaseManager
    {
        private static readonly InventoriesEntities entities;

        // Initialize and open the database connection
        static DatabaseManager()
        {
            entities = new InventoriesEntities();
            entities.Database.Connection.Open();
        }

        // Provide an accessor to the database
        public static InventoriesEntities Instance
        {
            get
            {
                return entities;
            }
        }
    }
}

//1  //030717 2:38pm NO Error.
    //0 references: DatabaseManager & InventoriesEntities.