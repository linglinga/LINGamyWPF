﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace HW3SortListView.Models
{
    
        class User : IDataErrorInfo, INotifyPropertyChanged
        {
            private string name = string.Empty;
            private string password = string.Empty;
            private string nameError;

            // Add ToString method
            public override string ToString()
            {
                return name;
            }

            public string NameError
            {
                get
                {
                    return nameError;
                }
                set
                {
                    if (nameError != value)
                    {
                        nameError = value;
                        OnPropertyChanged("NameError");
                    }
                }
            }

            public string Name
            {
                get
                {                   //10        //16        //22        //34.       //40        //46
                    return name;    //11. Dave  //17 Steve  //23 Lisa   //35 Dave   //41 Lisa   //47 Steve
                }                   //12        //18        //24        //36        //42        //48
                set
                {
                    if (name != value)
                    {
                        name = value;
                        OnPropertyChanged("Name");
                    }
                }
            }

            public string Password
            {
                get
                {                       //13            //19            //25            //37            //43            //49
                    return password;    //14 1DavePwd   //20 2StevePwd  //26 3LisaPwd   //38 1DavePwd   //44 3LisaPwd   //50 2StevePwd
                }                       //15            //21            //27 SortWindow pop up with all 3 user name and passwords.  //39    //45    //51
                set
                {
                    if (password != value)
                    {
                        password = value;
                        OnPropertyChanged("Password");
                    }
                }
            }

            // IDataErrorInfo interface
            public string Error
            {
                get
                {
                    return NameError;
                }
            }

            // IDataErrorInfo interface
            // Called when ValidatesOnDataErrors=True
            public string this[string columnName]
            {
                get
                {
                    NameError = "";
                    switch (columnName)
                    {
                        case "Name":
                            {
                                if (string.IsNullOrEmpty(Name))
                                {
                                    NameError = "Name cannot be empty.";
                                }
                                if (Name.Length > 12)
                                {
                                    NameError = "Name cannot be longer than 12 characters.";
                                }
                                break;
                            }
                    }
                    return NameError;
                }
            }

            // INotifyPropertyChanged interface
            public event PropertyChangedEventHandler PropertyChanged;

            protected void OnPropertyChanged(string propertyName)
            {
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
                }
            }
        }
    }

