﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HW3SortListView
{
    /// <summary>
    /// Interaction logic for SortWindow.xaml
    /// </summary>
    public partial class SortWindow : Window
    {
        public SortWindow()         //1
        {                           //2
            InitializeComponent();  //3

            var users = new List<Models.User>();    //4

            users.Add(new Models.User { Name = "Dave", Password = "1DavePwd" });    //5
            users.Add(new Models.User { Name = "Steve", Password = "2StevePwd" });  //6
            users.Add(new Models.User { Name = "Lisa", Password = "3LisaPwd" });    //7

            uxList.ItemsSource = users;     //8
        }                           //9

        private void GridViewColumnHeader_Click(object sender, RoutedEventArgs e)
        {                                                                           //28 click on either header and this click event executes.
            //1send the tag into a string format I can sortBy:variable.
            GridViewColumnHeader column = (sender as GridViewColumnHeader);         //29 column of Name
            
            // Grab the Tag from the column header            
            string sortBy = column.Tag.ToString();                                  //30 column tag of Name
            
            // Clear out any previous column sorting            
            uxList.Items.SortDescriptions.Clear();                                  //31 Count becomes 0
           
            // Sort the uxContactList by the column header tag (sortBy)            
            // If you want to do Descending, look at the homework :) and SortAdorner            
            //2pass the sortBy into this method.
            var sortDescription = new System.ComponentModel.SortDescription(sortBy, System.ComponentModel.ListSortDirection.Ascending);
                                                                                        //32 propertyName: same as tag (Name)
            //3uxList... is the ListView.
            uxList.Items.SortDescriptions.Add(sortDescription);                     //33 count is 1
        }
        
    }
}
