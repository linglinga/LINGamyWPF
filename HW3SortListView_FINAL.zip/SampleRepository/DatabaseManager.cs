﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SampleDB;


namespace SampleRepository
{
    class DatabaseManager
    {
        private static readonly SampleEntities entities;

        // Initialize and open the database connection
        static DatabaseManager()
        {
            entities = new SampleEntities();
            entities.Database.Connection.Open();
        }

        // Provide an accessor to the database
        public static SampleEntities Instance
        {
            get
            {
                return entities;

            }
        }
    }
}
